// import React from 'react';

// // Functional Component: PersonCard
// const PersonCard = (props) => {
// const { firstName, lastName, age, hairColor } = props;

// return (
//     <div className="person-card">
//     <h2>{lastName}, {firstName}</h2>
//     <p>Age: {age}</p>
//     <p>Hair Color: {hairColor}</p>
//     </div>
// );
// };

// // Functional Component: App
// const App = () => {
// return (
//     <div className="app">
//     <PersonCard
//         firstName="John"
//         lastName="Doe"
//         age={30}
//         hairColor="Brown"
//     />
//     <PersonCard
//         firstName="Jane"
//         lastName="Smith"
//         age={25}
//         hairColor="Blonde"
//     />
//     <PersonCard
//         firstName="Michael"
//         lastName="Johnson"
//         age={40}
//         hairColor="Black"
//     />
//     <PersonCard
//         firstName="Emily"
//         lastName="Williams"
//         age={28}
//         hairColor="Red"
//     />
//     </div>
// );
// };

// export default App;